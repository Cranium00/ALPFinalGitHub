package com.example.UserLicense.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "UserLicenseAssociation")
public class UserLicense {

    @Id
    String licenseKey;
    Long userId;
    String status;
}
